// --- Navigation Menu Logic ---
function openNav() {
    document.getElementById("sidebar-menu").style.width = "250px";
}

function closeNav() {
    document.getElementById("sidebar-menu").style.width = "0";
}

// Function to explicitly set the navigation source
function setSummarySource(source) {
    localStorage.setItem('summarySource', source);
}

// Function to generate a random MAC address
function getRandomMac() {
    let mac = '';
    for (let i = 0; i < 6; i++) {
        mac += Math.floor(Math.random() * 256).toString(16).padStart(2, '0').toUpperCase();
        if (i < 5) mac += ':';
    }
    return mac;
}

// --- Data storage and generation ---
let simulatedData = [];
let alertsHistory = [];
let honeypotLogs = [];

function generateAllData() {
    const LEGITIMATE_NETWORKS = {
        'HomeOfficeNet': 'A1:B2:C3:D4:E5:F6',
        'SecureGuestNet': 'F6:E5:D4:C3:B2:A1'
    };

    const ROGUE_NETWORKS = [
        { ssid: 'HomeOfficeNet_Fake', bssid: 'A1:B2:C3:D4:E5:F7', signal: -45, security: 'WPA2' },
        { ssid: 'Free_Public_WiFi_Attack', bssid: '00:11:22:33:44:55', signal: -60, security: 'Open' },
        { ssid: 'SecureGuestNet_EvilTwin', bssid: 'F6:E5:D4:C3:B2:A2', signal: -55, security: 'WPA2' },
        { ssid: 'Starbucks_Guest_Network', bssid: getRandomMac(), signal: -58, security: 'Open' },
        { ssid: 'Airport_Free_Network_2', bssid: getRandomMac(), signal: -62, security: 'Open' },
        { ssid: 'Free_Hotspot_123', bssid: getRandomMac(), signal: -65, security: 'Open' },
        { ssid: 'linksys_guest_open', bssid: getRandomMac(), signal: -70, security: 'Open' },
        { ssid: 'Open_Network_99', bssid: getRandomMac(), signal: -40, security: 'Open' },
        { ssid: 'XFINITY_Wi-Fi_Rogue', bssid: getRandomMac(), signal: -50, security: 'Open' },
        { ssid: 'TP-LINK_Free', bssid: getRandomMac(), signal: -75, security: 'Open' },
        { ssid: 'Net_Security_Test_AP', bssid: getRandomMac(), signal: -48, security: 'Open' },
        { ssid: 'Secure_Network_Hack', bssid: getRandomMac(), signal: -52, security: 'Open' },
        { ssid: 'Internet_For_Free_1', bssid: getRandomMac(), signal: -63, security: 'Open' },
        { ssid: 'AndroidAP_2_Evil', bssid: getRandomMac(), signal: -80, security: 'Open' },
        { ssid: 'Verizon_WiFi_Clone_AP', bssid: getRandomMac(), signal: -44, security: 'Open' },
        { ssid: 'Public_WiFi_5G_Threat', bssid: getRandomMac(), signal: -68, security: 'Open' },
        { ssid: 'Hotel_Guest_Trap', bssid: getRandomMac(), signal: -55, security: 'Open' },
        { ssid: 'My_Office_AP_Rogue', bssid: getRandomMac(), signal: -42, security: 'Open' },
        { ssid: 'Evil_Access_Point_Trap', bssid: getRandomMac(), signal: -59, security: 'Open' },
        { ssid: 'Free_Internet_Service_Scam', bssid: getRandomMac(), signal: -61, security: 'Open' },
    ];

    let allData = [];
    let uniqueSSIDs = new Set();
    const FAKE_NETWORKS_COUNT = 80;
    const FAKE_SSID_PREFIXES = ['Wireless', 'Public', 'Guest', 'Network', 'Net', 'Router', 'Home', 'Link', 'Dombivli', 'Cafe', 'Office'];

    allData.push(...Object.values(LEGITIMATE_NETWORKS).map(bssid => ({ ssid: Object.keys(LEGITIMATE_NETWORKS).find(key => LEGITIMATE_NETWORKS[key] === bssid), bssid, signal: Math.floor(Math.random() * (60 - 40 + 1) - 60), security: 'WPA2' })));
    allData.push(...ROGUE_NETWORKS);

    allData.forEach(ap => uniqueSSIDs.add(ap.ssid));

    for (let i = 0; i < FAKE_NETWORKS_COUNT; i++) {
        let ssid = '';
        do {
            ssid = `${FAKE_SSID_PREFIXES[Math.floor(Math.random() * FAKE_SSID_PREFIXES.length)]}_${Math.floor(Math.random() * 9999) + 1000}`;
        } while (uniqueSSIDs.has(ssid));
        uniqueSSIDs.add(ssid);
        
        const bssid = getRandomMac();
        const signal = Math.floor(Math.random() * (90 - 40 + 1) - 90);
        const security = (Math.random() > 0.8) ? 'Open' : 'WPA2';
        allData.push({ ssid, bssid, signal, security: security });
    }
    
    const HONEYPOT_LOGS = [
        { device: 'Samsung-Galaxy-S21', mac: '1A:2B:3C:4D:5E:6F', date: '14-09-2025', time: '10:30:15' },
        { device: 'iPhone 13', mac: '2C:3D:4E:5F:6A:7B', date: '14-09-2025', time: '10:31:02' },
        { device: 'Laptop-User-PC', mac: '3D:4E:5F:6A:7B:8C', date: '14-09-2025', time: '10:31:45' },
    ];
    
    const ALERTS_HISTORY = ROGUE_NETWORKS.map(ap => ({
        ssid: ap.ssid,
        bssid: ap.bssid,
        reason: ap.reason,
        date: '14-09-2025',
        time: `${Math.floor(Math.random() * 24).toString().padStart(2, '0')}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`
    }));

    allData.forEach(ap => {
        ap.reason = ap.reason || 'N/A';
        ap.status = 'safe';
        
        const isLegitSSID = LEGITIMATE_NETWORKS[ap.ssid];
        if (isLegitSSID && isLegitSSID !== ap.bssid) {
            ap.status = 'unsafe';
            ap.reason = 'Evil Twin (Spoofed BSSID)';
        } else if (ROGUE_NETWORKS.some(r => r.ssid === ap.ssid)) {
            ap.status = 'unsafe';
            const rogueReason = ROGUE_NETWORKS.find(r => r.ssid === ap.ssid)?.reason;
            if (rogueReason) ap.reason = rogueReason;
        } else if (ap.security === 'Open' && (ap.ssid.toLowerCase().includes('free') || ap.ssid.toLowerCase().includes('public') || ap.ssid.toLowerCase().includes('guest'))) {
            ap.status = 'unsafe';
            ap.reason = 'Suspicious Open Network';
        }
    });

    localStorage.setItem('simulatedData', JSON.stringify(allData));
    localStorage.setItem('honeypotLogs', JSON.stringify(HONEYPOT_LOGS));
    localStorage.setItem('alertsHistory', JSON.stringify(ALERTS_HISTORY));
}

if (!localStorage.getItem('simulatedData')) {
    generateAllData();
}

simulatedData = JSON.parse(localStorage.getItem('simulatedData'));
honeypotLogs = JSON.parse(localStorage.getItem('honeypotLogs'));
alertsHistory = JSON.parse(localStorage.getItem('alertsHistory'));

function getSimulatedData() {
    return simulatedData;
}

function getHoneypotLogs() {
    return honeypotLogs;
}

function getAlertsHistory() {
    return alertsHistory;
}

// --- Home Page Logic ---
if (window.location.pathname.endsWith('home.html')) {
    const allNetworks = getSimulatedData();
    
    const ssidGrid = document.getElementById('ssid-grid');
    const notificationBar = document.getElementById('notification-bar');
    const notificationMessage = document.getElementById('notification-message');
    
    ssidGrid.innerHTML = '';
    allNetworks.forEach(network => {
        const cardLink = document.createElement('a');
        cardLink.href = '#';
        cardLink.classList.add('ssid-card');
        
        const statusClass = network.status === 'unsafe' ? 'unsafe-text' : 'safe-text';
        const securityIcon = network.status === 'unsafe' ? 
            `<i class="fas fa-exclamation-triangle"></i>` :
            `<i class="fas fa-shield-alt"></i>`;

        cardLink.innerHTML = `
            <div class="card-header">
                <h3 class="${statusClass}">${network.ssid}</h3>
                <span class="security-icon ${statusClass}">${securityIcon}</span>
            </div>
            <p><strong>Signal:</strong> ${network.signal} dBm</p>
            <p><strong>Security:</strong> ${network.security}</p>
        `;

        cardLink.onclick = function(e) {
            e.preventDefault();
            localStorage.setItem('selectedSSID', JSON.stringify(network));
            localStorage.setItem('summarySource', 'homepage');
            
            notificationMessage.innerHTML = `
                Analyzing network... 
                <a href="summary.html">Click for full summary</a>
            `;
            notificationBar.style.display = 'block';
        };
        
        ssidGrid.appendChild(cardLink);
    });
}

// --- Summary Page Logic ---
if (window.location.pathname.endsWith('summary.html')) {
    const summaryContent = document.getElementById('summary-content');
    const summaryGrid = document.getElementById('summary-grid');
    const selectedSSID = JSON.parse(localStorage.getItem('selectedSSID'));
    const allNetworks = getSimulatedData();
    const summarySource = localStorage.getItem('summarySource');
    
    if (summarySource === 'homepage' && selectedSSID) {
        let statusMessage = 'This network is safe and secure.';
        let className = 'safe-text';
        
        if (selectedSSID.status === 'unsafe') {
            statusMessage = `This network is <strong>dangerous</strong>! Reason: ${selectedSSID.reason}. Avoid connecting to it.`;
            className = 'unsafe-text';
        }
        
        summaryContent.innerHTML = `
            <h2>Summary for: <span class="${className}">${selectedSSID.ssid}</span></h2>
            <p><strong>BSSID:</strong> ${selectedSSID.bssid}</p>
            <p><strong>Signal Strength:</strong> ${selectedSSID.signal} dBm</p>
            <p><strong>Security Type:</strong> ${selectedSSID.security}</p>
            <p class="status-message ${className}">${statusMessage}</p>
        `;
        summaryGrid.style.display = 'none';
    } else {
        summaryContent.innerHTML = `
            <h2>Overall Network Summary</h2>
            <p>Below is a quick overview of all detected networks.</p>
        `;
        summaryGrid.style.display = 'grid';
        summaryGrid.innerHTML = '';

        allNetworks.forEach(network => {
            const cardLink = document.createElement('div');
            cardLink.classList.add('ssid-card');

            const statusClass = network.status === 'unsafe' ? 'unsafe-text' : 'safe-text';
            const securityIcon = network.status === 'unsafe' ? 
                `<i class="fas fa-exclamation-triangle ${statusClass}"></i>` :
                `<i class="fas fa-shield-alt ${statusClass}"></i>`;

            cardLink.innerHTML = `
                <div class="card-header">
                    <h3 class="${statusClass}">${network.ssid}</h3>
                    <span class="security-icon ${statusClass}">${securityIcon}</span>
                </div>
                <p><strong>Signal:</strong> ${network.signal} dBm</p>
                <p><strong>Security:</strong> ${network.security}</p>
                <p class="status-message ${statusClass}">${network.status === 'unsafe' ? network.reason : 'Safe'}</p>
            `;
            
            summaryGrid.appendChild(cardLink);
        });
    }
    localStorage.removeItem('summarySource');
}

// --- Alerts History Logic ---
if (window.location.pathname.endsWith('alerts.html')) {
    const alertsTableBody = document.querySelector('#alerts-table tbody');
    alertsTableBody.innerHTML = '';
    const alertsData = getAlertsHistory();
    alertsData.forEach(alert => {
        const tr = document.createElement('tr');
        tr.classList.add('unsafe-row');
        tr.innerHTML = `
            <td>${alert.ssid}</td>
            <td>${alert.bssid || 'N/A'}</td>
            <td class="unsafe-text">${alert.reason}</td>
            <td>${alert.date}</td>
            <td>${alert.time}</td>
        `;
        alertsTableBody.appendChild(tr);
    });
}


// --- Dashboard Logic ---
if (window.location.pathname.endsWith('index.html')) {
    const statusFilter = document.getElementById('status-filter');
    if (statusFilter) {
        statusFilter.addEventListener('change', updateDashboard);
    }
    
    function updateDashboard() {
        const allNetworks = getSimulatedData();
        const selectedStatus = statusFilter ? statusFilter.value : 'all';
        let filteredNetworks = allNetworks;
        
        if (selectedStatus !== 'all') {
            filteredNetworks = allNetworks.filter(network => network.status === selectedStatus);
        }
        
        const honeypotData = getHoneypotLogs();

        updateTable('ap-table', filteredNetworks, ['ssid', 'bssid', 'signal', 'security', 'status', 'reason']);
        updateTable('honeypot-table', honeypotData, ['device', 'mac', 'date', 'time']);
    }

    function updateTable(tableId, data, keys = null) {
        const tableBody = document.querySelector(`#${tableId} tbody`);
        if (!tableBody) return;
        tableBody.innerHTML = '';
        data.forEach(row => {
            const tr = document.createElement('tr');
            
            if (row.status === 'unsafe') {
                tr.classList.add('unsafe-row');
            }

            const displayKeys = keys || Object.keys(row);
            displayKeys.forEach(key => {
                const td = document.createElement('td');
                
                if (key === 'status') {
                    td.classList.add(row.status + '-text');
                    td.innerHTML = `<b>${row[key].toUpperCase()}</b>`;
                } else if (key === 'reason') {
                    if (row.status === 'unsafe') {
                        td.classList.add('unsafe-text');
                    }
                    td.textContent = row[key];
                }
                else {
                    td.textContent = row[key];
                }
                tr.appendChild(td);
            });
            tableBody.appendChild(tr);
        });
    }
    
    setInterval(updateDashboard, 5000);
    document.addEventListener('DOMContentLoaded', updateDashboard);
}

// --- Login/Sign-up Logic ---
const loginForm = document.getElementById('login-form');
const signupForm = document.getElementById('signup-form');
const showSignupLink = document.getElementById('show-signup');
const showLoginLink = document.getElementById('show-login');
const loginFormContainer = document.getElementById('login-form-container');
const signupFormContainer = document.getElementById('signup-form-container');

if (showSignupLink) {
    showSignupLink.addEventListener('click', (e) => {
        e.preventDefault();
        loginFormContainer.style.display = 'none';
        signupFormContainer.style.display = 'block';
    });
}

if (showLoginLink) {
    showLoginLink.addEventListener('click', (e) => {
        e.preventDefault();
        signupFormContainer.style.display = 'none';
        loginFormContainer.style.display = 'block';
    });
}

if (loginForm) {
    loginForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        if (username === 'admin' && password === 'password') {
            window.location.href = 'home.html';
        } else {
            alert('Incorrect username or password.');
        }
    });
}

if (signupForm) {
    signupForm.addEventListener('submit', (e) => {
        e.preventDefault();
        alert('Account created! Please proceed to login.');
        window.location.href = 'login.html'; 
    });
}

// --- How to Use Logic ---
function toggleDetails(element) {
    const detailsContent = element.nextElementSibling;
    if (detailsContent.style.display === 'block') {
        detailsContent.style.display = 'none';
        element.querySelector('p').textContent = 'Click for more details';
    } else {
        detailsContent.style.display = 'block';
        element.querySelector('p').textContent = 'Hide details';
    }
}